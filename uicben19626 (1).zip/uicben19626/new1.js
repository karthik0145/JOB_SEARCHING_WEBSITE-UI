
  function s(y)
  {if(y==9)
    {
     var z=document.aa.zz;
     z.value="ALL-DOMAIN";
     document.getElementById("qwe").style.display = "block";
     document.getElementById("qwe1").style.display = "none";
     document.getElementById("qwe2").style.display = "none";
     document.getElementById("qwe3").style.display = "none";
     document.getElementById("qwe4").style.display = "none";
     document.getElementById("qwe5").style.display = "none";
     document.getElementById("qwe6").style.display = "none";
     document.getElementById("qwe7").style.display = "none";
  
      document.getElementById("qwe8").style.display = "none";
    }
      if(y==1)
      {
       var z=document.aa.zz;
       z.value="ANALYTICS";
       document.getElementById("qwe1").style.display = "block";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
    
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==2)
      {
       var z=document.aa.zz;
       z.value="PRODUCT-SOFTWARE";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
        document.getElementById("qwe2").style.display = "block";
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==3)
      {
       var z=document.aa.zz;
       z.value="SOFTWARE-SERVICES";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
        document.getElementById("qwe3").style.display = "block";
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==4)
      {
       var z=document.aa.zz;
       z.value="TELECOM";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
        document.getElementById("qwe4").style.display = "block";
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==5)
      {
       var z=document.aa.zz;
       z.value="DIARY";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
        document.getElementById("qwe5").style.display = "block";
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==6)
      {
       var z=document.aa.zz;
       z.value="MINING";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
        document.getElementById("qwe6").style.display = "block";
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==7)
      {
       var z=document.aa.zz;
       z.value="HEALTH-CARE";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
        document.getElementById("qwe7").style.display = "block";
        document.getElementById("qwe8").style.display = "none";
      }
      if(y==8)
      {
       var z=document.aa.zz;
       z.value="INSURANCE";
       document.getElementById("qwe").style.display = "none";
       document.getElementById("qwe2").style.display = "none";
       document.getElementById("qwe3").style.display = "none";
       document.getElementById("qwe4").style.display = "none";
       document.getElementById("qwe5").style.display = "none";
       document.getElementById("qwe6").style.display = "none";
       document.getElementById("qwe7").style.display = "none";
       document.getElementById("qwe1").style.display = "none";
        document.getElementById("qwe8").style.display = "block";
      }
  }
    function fun1(){
        document.getElementById("hh").style.borderColor = "chartreuse";
        setInterval(fun2,3000);
    }
    function fun2(){
      document.getElementById("hh").style.borderColor = "skyblue";
        setInterval(colorc,3000);
    }
    window.onload=colorc;
   


        
        function idm1()
        {
            var x=document.querySelector(".name");
            document.getElementById('immg1').style.display = "none";
            document.getElementById("aa").innerHTML="Welcome "+x.value;
             document.getElementById("demo").style.display="none";
         

        }
        